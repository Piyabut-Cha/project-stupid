<nav>
    <div class="nav-container">
        <a href="index.html">
            <img src="./imgs/logo-shabu.png" class="logonav" width="100px" height="100px">
        </a>
        <ul class="nav-tabs">
            <li><a href="index.html" class="active">Home</a></li>
            <li><a href="store.php">Store</a></li>
            <li><a href="contact.html">Contact</a></li>
        </ul>
        <div class="nav-profile">
            </div>
    </div>
</nav>
