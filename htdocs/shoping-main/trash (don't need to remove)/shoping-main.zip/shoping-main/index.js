// var product = [{
//     id: 1,
//     img: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?crop=entropy&cs=tinysrgb&fm=jpg&ixlib=rb-1.2.1&q=80&raw_url=true&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1740',
//     name: 'Nike',
//     price: 7000,
//     description: 'Nike Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quam, labore dolorum optio ad consequatur cupiditate!',
//     type: 'shoe'
// }, {
//     id: 2,
//     img: 'https://images.unsplash.com/photo-1511746315387-c4a76990fdce?ixlib=rb-1.2.1&raw_url=true&q=80&fm=jpg&crop=entropy&cs=tinysrgb&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1740',
//     name: 'Adidas shirt',
//     price: 1500,
//     description: 'Adidas shirt Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quam, labore dolorum optio ad consequatur cupiditate!',
//     type: 'shirt'
// }, {
//     id: 3,
//     img: 'https://images.unsplash.com/photo-1593287073863-c992914cb3e3?crop=entropy&cs=tinysrgb&fm=jpg&ixlib=rb-1.2.1&q=80&raw_url=true&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=774',
//     name: 'Adidas shoe',
//     price: 45000,
//     description: 'Adidas shoe Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quam, labore dolorum optio ad consequatur cupiditate!',
//     type: 'shoe'
// }];

var product;

// [{},{},{}] // length = 3

$(document).ready(() => {

    $.ajax({
        method: 'get',
        url: './api/getallproduct.php',
        success: function(response) {
            console.log(response)
            if(response.RespCode == 200) {

                product = response.Result;

                var html = '';
                for (let i = 0; i < product.length; i++) {
                    html += `<div onclick="openProductDetail(${i})" class="product-items ${product[i].type}">
                                <img class="product-img" src="./imgs/${product[i].img}" alt="">
                                <p style="font-size: 1.2vw;">${product[i].name}</p>
                                <p stlye="font-size: 1vw;">${ numberWithCommas(product[i].price) } THB</p>
                            </div>`;
                }
                $("#productlist").html(html);
            }
        }, error: function(err) {
            console.log(err)
        }
    })
})

function numberWithCommas(x) {
    x = x.toString();
    var pattern = /(-?\d+)(\d{3})/;
    while (pattern.test(x))
        x = x.replace(pattern, "$1,$2");
    return x;
}

function searchsomething(elem) {
    // console.log('#'+elem.id)
    var value = $('#'+elem.id).val()
    console.log(value)

    var html = '';
    for (let i = 0; i < product.length; i++) {
        if( product[i].name.includes(value) ) {
            html += `<div onclick="openProductDetail(${i})" class="product-items ${product[i].type}">
                    <img class="product-img" src="./imgs/${product[i].img}" alt="">
                    <p style="font-size: 1.2vw;">${product[i].name}</p>
                    <p stlye="font-size: 1vw;">${ numberWithCommas(product[i].price) } THB</p>
                </div>`;
        }
    }
    if(html == '') {
        $("#productlist").html(`<p>Not found product</p>`);
    } else {
        $("#productlist").html(html);
    }

}

function searchproduct(param) {
    console.log(param)
    $(".product-items").css('display', 'none')
    if(param == 'all') {
        $(".product-items").css('display', 'block')
    }
    else {
        $("."+param).css('display', 'block')
    }
}

var productindex = 0;
function openProductDetail(index) {
    productindex = index;
    console.log(productindex)
    $("#modalDesc").css('display', 'flex')
    $("#mdd-img").attr('src', './imgs/' + product[index].img);
    $("#mdd-name").text(product[index].name)
    $("#mdd-price").text( numberWithCommas(product[index].price) + ' THB')
    $("#mdd-desc").text(product[index].description)
}

function closeModal() {
    $(".modal").css('display','none')
}

var cart = [];
function addtocart() {
    var pass = true;

    for (let i = 0; i < cart.length; i++) {
        if( productindex == cart[i].index ) {
            console.log('found same product')
            cart[i].count++;
            pass = false;
        }
    }

    if(pass) {
        var obj = {
            index: productindex,
            id: product[productindex].id,
            name: product[productindex].name,
            price: product[productindex].price,
            img: product[productindex].img,
            count: 1
        };
        // console.log(obj)
        cart.push(obj)
    }
    console.log(cart)

    Swal.fire({
        icon: 'success',
        title: 'Add ' + product[productindex].name + ' to cart !'
    })
    $("#cartcount").css('display','flex').text(cart.length)
}

function openCart() {
    $('#modalCart').css('display','flex')
    rendercart();
}

function updateTotalPrice() {
    var totalPrice = 0;
  
    for (let i = 0; i < cart.length; i++) {
      totalPrice += cart[i].price * cart[i].count;
    }
  
    $("#totalPrice").text(numberWithCommas(totalPrice) + " THB");
  }
  
  function rendercart() {
    if (cart.length > 0) {
      var html = '';
  
      for (let i = 0; i < cart.length; i++) {
        html += `<div class="cartlist-items">
                  <div class="cartlist-left">
                      <img src="./imgs/${cart[i].img}" alt="">
                      <div class="cartlist-detail">
                          <p style="font-size: 1.5vw;">${cart[i].name}</p>
                          <p style="font-size: 1.2vw;">${numberWithCommas(cart[i].price * cart[i].count)} THB</p>
                      </div>
                  </div>
                  <div class="cartlist-right">
                      <p onclick="deinitems('-', ${i})" class="btnc">-</p>
                      <p id="countitems${i}" style="margin: 0 20px;">${cart[i].count}</p>
                      <p onclick="deinitems('+', ${i})" class="btnc">+</p>
                  </div>
              </div>`;
      }
  
      // Append the total price to the cart HTML
      html += `<div class="cartlist-items">
                  <div class="cartlist-left">
                      <p style="font-size: 1.5vw;">Total Price</p>
                  </div>
                  <div class="cartlist-right">
                      <p id="totalPrice" style="font-size: 1.2vw;"></p>
                  </div>
              </div>`;
  
      $("#mycart").html(html);
  
      updateTotalPrice(); // Calculate and update the initial total price
  
    } else {
      $("#mycart").html(`<p>Not found product list</p>`);
    }
  }
  
  // Function to handle decreasing and increasing item counts
  function deinitems(action, index) {
    if (action == "-") {
      if (cart[index].count > 0) {
        cart[index].count--;
        $("#countitems" + index).text(cart[index].count);
  
        if (cart[index].count <= 0) {
          Swal.fire({
            icon: "warning",
            title: "Are you sure to delete?",
            showConfirmButton: true,
            showCancelButton: true,
            confirmButtonText: "Delete",
            cancelButtonText: "Cancel"
          }).then((res) => {
            if (res.isConfirmed) {
              cart.splice(index, 1);
              rendercart();
              $("#cartcount").css("display", "flex").text(cart.length);
  
              if (cart.length <= 0) {
                $("#cartcount").css("display", "none");
              }
            } else {
              cart[index].count++;
              $("#countitems" + index).text(cart[index].count);
            }
          });
        }
      }
    } else if (action == "+") {
      cart[index].count++;
      $("#countitems" + index).text(cart[index].count);
    }
  
    updateTotalPrice(); // Update the total price after a count change
  }
  

function buynow() {
    $.ajax({
        method: 'post',
        url: './api/buynow.php',
        data: {
            product: cart
        }, success: function(response) {
            console.log(response)
            if(response.RespCode == 200) {
                Swal.fire({
                    icon: 'success',
                    title: 'Thank you',
                    html: ` <p> จำนวนเงิน : ${response.Amount.Amount} บาท</p>
                            <p> ยอดเงินสุทธิ : ${response.Amount.Netamount} บาท</p>
                            `
                }).then((res) => {
                    if(res.isConfirmed) {
                        cart = [];
                        closeModal();
                        $("#cartcount").css('display','none')
                    }
                })
            }
            else {
                Swal.fire({
                    icon: 'error',
                    title: 'Something is went wrong!'
                })
            }
        }, error: function(err) {
            console.log(err)
        }
    })
}
